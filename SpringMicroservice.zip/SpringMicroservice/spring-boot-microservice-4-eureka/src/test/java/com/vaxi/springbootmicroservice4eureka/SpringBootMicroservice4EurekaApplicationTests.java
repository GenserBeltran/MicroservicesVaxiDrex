package com.vaxi.springbootmicroservice4eureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMicroservice4EurekaApplicationTests {

	@Test
	void contextLoads() {
	}

}
