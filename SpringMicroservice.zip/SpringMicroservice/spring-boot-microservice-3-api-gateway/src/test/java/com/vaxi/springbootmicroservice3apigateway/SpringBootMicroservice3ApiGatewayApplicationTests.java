package com.vaxi.springbootmicroservice3apigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMicroservice3ApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
