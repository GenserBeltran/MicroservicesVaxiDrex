package com.vaxi.springbootmicroservice3apigateway.model;

public enum Role {
    USER,
    ADMIN
}
