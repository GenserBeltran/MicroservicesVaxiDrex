package com.vaxi.springbootmicroservice1inmueble;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMicroservice1InmuebleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMicroservice1InmuebleApplication.class, args);
	}

}
