export const environment = {
  production: false,
  name:'dev',
  firebase: {
    config :{
      apiKey: "AIzaSyBBw_PHD2nfnjWsqCysEdIMPnjh507Qq08",
      authDomain: "angular-test-6c2ba.firebaseapp.com",
      projectId: "angular-test-6c2ba",
      storageBucket: "angular-test-6c2ba.appspot.com",
      messagingSenderId: "198825047659",
      appId: "1:198825047659:web:247117caa8d461370aa32e"
    }
  },
  url:'http://localhost:5555/'
};
