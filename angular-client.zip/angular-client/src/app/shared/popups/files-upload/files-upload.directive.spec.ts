import { FilesUploadDirective } from './files-upload.directive';

describe('FilesUploadDirective', () => {
  it('should create an instance', () => {
    const directive = new FilesUploadDirective();
    expect(directive).toBeTruthy();
  });
});
